// 3단계: 장면 조립.  node scripts/build.mjs <작업폴더>
// 읽는 것: 작업폴더/scenes.json, timing.json, (있으면) style.json, 내캐릭터/*.png
// 만드는 것: 작업폴더/hf/ (HyperFrames 프로젝트), 작업폴더/sfx_cues.json
import fs from "node:fs";
import path from "node:path";
import { SKILL_DIR, loadStyle, run, need } from "./lib.mjs";

const work = path.resolve(process.argv[2] || ".");
const st = loadStyle(work);
need(path.join(work, "scenes.json"), "scenes.json 이 없어요.");
need(path.join(work, "timing.json"), "timing.json 이 없어요. voice.mjs 를 먼저 돌려 주세요.");
const SC = JSON.parse(fs.readFileSync(path.join(work, "scenes.json"), "utf8"));
const TM = JSON.parse(fs.readFileSync(path.join(work, "timing.json"), "utf8"));
const hf = path.join(work, "hf");
fs.mkdirSync(path.join(hf, "fonts"), { recursive: true });
fs.mkdirSync(path.join(hf, "assets"), { recursive: true });
fs.mkdirSync(path.join(hf, "char"), { recursive: true });

// ── 파일 복사
for (const f of Object.values(st.fonts)) fs.copyFileSync(path.join(SKILL_DIR, "fonts", f), path.join(hf, "fonts", f));
fs.copyFileSync(path.join(SKILL_DIR, "template", "paper.jpg"), path.join(hf, "assets", "paper.jpg"));
fs.copyFileSync(path.join(work, "narration.wav"), path.join(hf, "assets", "narration.wav"));
fs.writeFileSync(path.join(hf, "hyperframes.json"), JSON.stringify({ paths: { assets: "assets" } }, null, 2));
fs.writeFileSync(path.join(hf, "package.json"), JSON.stringify({ name: "paper-reel", private: true, type: "module" }, null, 2));

// ── 캐릭터: 내캐릭터 폴더의 그림(배경 자동 제거) 또는 기본 손그림 캐릭터
const POSES = ["idle", "point", "happy", "think", "shrug", "wave"];
const KO = { 기본: "idle", 가리키기: "point", 신남: "happy", 고민: "think", 으쓱: "shrug", 손인사: "wave" };
const charDir = path.join(work, st.character.folder);
const userChars = {};
if (fs.existsSync(charDir)) {
  const imgs = fs.readdirSync(charDir).filter(f => /\.(png|jpe?g|webp)$/i.test(f)).sort();
  const keyed = [];
  for (const f of imgs) {
    const name = path.parse(f).name.toLowerCase().normalize("NFC");
    const pose = POSES.find(p => name.includes(p)) || Object.entries(KO).find(([k]) => name.includes(k))?.[1] || name;
    const tmpOut = path.join(hf, "char", `_k_${pose}.png`);
    cutout(path.join(charDir, f), tmpOut);
    keyed.push([pose, tmpOut]);
  }
  // 모든 포즈를 같은 상자로 잘라 여백 제거 (포즈가 바뀌어도 크기가 같게)
  let box = null;
  for (const [, f] of keyed) {
    const r = run("ffmpeg", ["-hide_banner", "-i", f, "-vf", "alphaextract,format=yuv420p,cropdetect=limit=24:round=2:reset=0:skip=0", "-f", "null", "-"], { allowFail: true });
    const m = [...r.stderr.matchAll(/crop=(\d+):(\d+):(\d+):(\d+)/g)].pop();
    if (!m) continue;
    const [w, h, x, y] = m.slice(1).map(Number);
    box = box ? [Math.min(box[0], x), Math.min(box[1], y), Math.max(box[2], x + w), Math.max(box[3], y + h)] : [x, y, x + w, y + h];
  }
  for (const [pose, f] of keyed) {
    const out = path.join(hf, "char", `${pose}.png`);
    if (box) {
      const pad = 16, x = Math.max(0, box[0] - pad), y = Math.max(0, box[1] - pad);
      run("ffmpeg", ["-v", "error", "-y", "-i", f, "-vf", `crop=w=min(iw-${x}\\,${box[2] - box[0] + pad * 2}):h=min(ih-${y}\\,${box[3] - box[1] + pad * 2}):x=${x}:y=${y}`, out]);
    } else fs.copyFileSync(f, out);
    fs.rmSync(f, { force: true });
    userChars[pose] = `char/${pose}.png`;
  }
}
const userPoseList = Object.keys(userChars);
function charSrc(pose) {
  if (!userPoseList.length) return null;
  return userChars[pose] || userChars.idle || userChars[userPoseList[0]];
}

// 배경 제거(무료·로컬): 모서리 색을 읽어 그 색을 투명하게. 초록 배경이면 초록 번짐도 지운다.
function cutout(src, dst) {
  const probe = run("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=pix_fmt", "-of", "csv=p=0", src]).stdout.trim();
  const px = run("ffmpeg", ["-v", "error", "-i", src, "-vf", "crop=6:6:2:2,scale=1:1:flags=area,format=rgba", "-f", "rawvideo", "-"], { encoding: "buffer" }).stdout;
  const [r, g, b, a] = [px[0], px[1], px[2], px[3]];
  if (/a/.test(probe) && a < 20) { fs.copyFileSync(src, dst); return; } // 이미 투명 배경
  const hex = "0x" + [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("");
  const isGreen = g > 150 && r < 120 && b < 120;
  const vf = isGreen
    ? `format=rgba,colorkey=${hex}:0.30:0.08`
    : `format=rgba,colorkey=${hex}:0.10:0.06`;
  run("ffmpeg", ["-v", "error", "-y", "-i", src, "-vf", vf, dst]);
}

// 기본 손그림 캐릭터(코드로 그림). 내캐릭터 폴더가 비어 있을 때만 씀
function defaultChar(pose) {
  const ink = st.colors.ink, acc = st.colors.point, body = "#FFFFFF";
  const arms = {
    idle: "M34 128 C 22 140, 16 152, 12 164 M166 128 C 178 140, 184 152, 188 164",
    point: "M34 128 C 22 140, 16 152, 12 164 M166 120 C 180 100, 188 80, 194 56",
    happy: "M34 118 C 20 100, 12 84, 8 62 M166 118 C 180 100, 188 84, 192 62",
    think: "M34 128 C 22 140, 16 152, 12 164 M166 132 C 150 150, 132 150, 118 138",
    shrug: "M34 124 C 18 118, 10 104, 8 92 M166 124 C 182 118, 190 104, 192 92",
    wave: "M34 128 C 22 140, 16 152, 12 164 M166 120 C 182 104, 190 86, 186 64",
  }[pose] || "";
  const mouth = {
    happy: `<path d="M86 128 Q100 146 114 128 Z" fill="${ink}" stroke="${ink}" stroke-width="4" stroke-linejoin="round"/>`,
    think: `<path d="M90 134 L108 131" />`,
    shrug: `<path d="M88 134 Q100 128 112 134" />`,
  }[pose] || `<path d="M88 128 Q100 138 112 128" />`;
  const extra = pose === "think" ? `<text x="168" y="54" font-family="Caveat" font-size="58" fill="${acc}" stroke="none">?</text>` : "";
  return `<svg viewBox="0 0 200 240" width="100%" height="100%" fill="none" stroke="${ink}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">
<ellipse cx="100" cy="230" rx="58" ry="7" fill="rgba(0,0,0,.08)" stroke="none"/>
<path d="M100 40 C 100 30, 99 22, 96 14" stroke-width="5"/>
<path d="M96 16 C 104 2, 124 0, 132 6 C 124 18, 108 22, 96 16 Z" fill="${acc}" stroke-width="4"/>
<path d="${arms}"/>
<path d="M80 196 C 78 208, 76 216, 72 224 M120 196 C 122 208, 124 216, 128 224"/>
<path d="M100 40 C 150 38, 178 72, 176 118 C 174 164, 140 198, 98 196 C 54 194, 24 160, 26 116 C 28 70, 56 42, 100 40 Z" fill="${body}"/>
<ellipse cx="80" cy="106" rx="7" ry="10" fill="${ink}" stroke="none"/><ellipse cx="120" cy="106" rx="7" ry="10" fill="${ink}" stroke="none"/>
<circle cx="82" cy="102" r="2.6" fill="#fff" stroke="none"/><circle cx="122" cy="102" r="2.6" fill="#fff" stroke="none"/>
${mouth}${extra}
</svg>`;
}

// ── 텍스트 도우미
const esc = s => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const units = s => [...String(s)].reduce((a, c) => a + (/[ㄱ-힣一-鿿]/.test(c) ? 0.96 : c === " " ? 0.3 : /[A-Z0-9]/.test(c) ? 0.62 : 0.5), 0) || 1;
const fit = (s, maxW, base) => Math.max(28, Math.min(base, Math.floor(maxW / units(s))));
// 길면 띄어쓰기에서 두 줄로 나누고, 긴 줄 기준으로 크기를 맞춘다
function fitLines(text, maxW, base) {
  let ls = String(text ?? "").split("\n");
  if (ls.length === 1 && units(ls[0]) * base > maxW && ls[0].includes(" ")) {
    const w = ls[0].split(" "); let best = null;
    for (let k = 1; k < w.length; k++) { const a = w.slice(0, k).join(" "), b = w.slice(k).join(" "); const m = Math.max(units(a), units(b)); if (!best || m < best[0]) best = [m, [a, b]]; }
    ls = best[1];
  }
  const size = Math.min(...ls.map(x => fit(x, maxW, base)));
  return { size, html: ls.map(esc).join("<br>") };
}
const isKo = s => /[ㄱ-힣]/.test(s);
const J = v => JSON.stringify(v);

// ── 장면 시간
const lines = TM.lines;
let used = 0;
const scenes = SC.scenes.map((s, i) => {
  const idx = (s.lines && s.lines.length) ? s.lines.map(n => n - 1) : [used];
  used = Math.max(...idx) + 1;
  return { ...s, _first: Math.min(...idx), _last: Math.max(...idx) };
});
if (used !== lines.length) console.warn(`주의: 장면이 맡은 문장 수(${used})와 대본 줄 수(${lines.length})가 달라요.`);
const END = +(TM.total + 0.45).toFixed(3);
scenes.forEach((s, i) => {
  s.t0 = i === 0 ? 0 : lines[s._first].start - 0.05;
  s.t1 = i === scenes.length - 1 ? END : lines[scenes[i + 1]._first].start - 0.05;
  s.d = s.t1 - s.t0;
});

// ── 장면 레시피
const cues = [];
const cue = (t, kind) => cues.push({ t: +t.toFixed(3), kind });
const TITLE_W = 900;

function titleHtml(s, i, narrow) {
  if (!s.title || !s.title.length) return "";
  const t = Array.isArray(s.title) ? s.title : [s.title];
  const hlIdx = s.hl === undefined ? t.length - 1 : s.hl;
  const w = narrow ? 640 : TITLE_W;
  const size = Math.min(...t.map(x => fit(x, w, st.sizes.title)));
  const top = s.title_top || 230;
  return `<div class="title" style="top:${top}px;font-size:${size}px;width:${w}px">` + t.map((x, k) =>
    `<span class="ln"><span id="t${i}_${k}">${k === hlIdx ? `<span class="hl">${esc(x)}<i id="h${i}"></i></span>` : esc(x)}</span></span>`).join("") + `</div>`;
}
function titleAnim(s, i, t0) {
  if (!s.title || !s.title.length) return "";
  const t = Array.isArray(s.title) ? s.title : [s.title];
  const hlIdx = s.hl === undefined ? t.length - 1 : s.hl;
  let js = t.map((_, k) => `up("t${i}_${k}",${(t0 + .05 + k * .1).toFixed(2)});`).join("");
  if (hlIdx >= 0 && hlIdx < t.length) { const tm = t0 + Math.min(1.0, s.d * .3); js += `mark("h${i}",${tm.toFixed(2)},.4);`; cue(tm, "pen"); }
  return js;
}
function noteHtml(s, i, x, y, rot = -7) {
  if (!s.note) return "";
  const ko = isKo(s.note);
  const size = ko ? 84 : 92;
  return `<div class="note ${ko ? "nko" : "nen"}" id="n${i}" style="left:${x}px;top:${y}px;font-size:${fit(s.note, 1000 - x, size)}px;transform:rotate(${rot}deg)">${esc(s.note)}</div>`;
}

const R = {
  // 큰 숫자 (숫자면 0부터 세어 올라감)
  bignum(s, i) {
    const hasTitle = s.title && s.title.length;
    const top = hasTitle ? 640 : 520;
    const numStr = String(s.num ?? "");
    const size = fit(numStr + (s.unit || ""), 860, hasTitle ? 280 : 330);
    return {
      html: (s.label ? `<div class="tape" style="left:${hasTitle ? 560 : 300}px;top:${hasTitle ? 560 : 160}px;width:300px;transform:rotate(-4deg)"></div><div class="memo" id="lb${i}" style="left:${hasTitle ? 520 : 250}px;top:${hasTitle ? 570 : 170}px;font-size:${fit(s.label, 480, 66)}px">${esc(s.label)}</div>` : "")
        + `<div class="bignum" style="top:${top}px;font-size:${size}px"><span id="num${i}">${esc(numStr)}</span><small>${esc(s.unit || "")}</small></div>`
        + (s.sub ? `<div class="memo sub" id="sb${i}" style="left:60px;width:960px;top:${top + size + 40}px;text-align:center;font-size:${fit(s.sub, 900, 76)}px;color:var(--gray)">${esc(s.sub)}</div>` : "")
        + noteHtml(s, i, 110, top + size + 150),
      anim: (t0, d) => {
        let js = s.label ? `fade("#lb${i}",${(t0 + .05).toFixed(2)},.35,20);` : "";
        const n = parseFloat(numStr.replace(/,/g, ""));
        if (/^[\d,.]+$/.test(numStr) && !isNaN(n)) {
          const dec = (numStr.split(".")[1] || "").length;
          js += `count("num${i}",${n},${dec},${(t0 + .15).toFixed(2)},${Math.min(1.4, d * .4).toFixed(2)});`;
        } else js += `fade("#num${i}",${(t0 + .15).toFixed(2)},.4,40);`;
        cue(t0 + .15, "pop");
        if (s.sub) js += `fade("#sb${i}",${(t0 + Math.min(1.6, d * .5)).toFixed(2)},.35,20);`;
        if (s.note) { const tm = t0 + Math.min(2.0, d * .6); js += `fade("#n${i}",${tm.toFixed(2)},.35,20);`; cue(tm, "pen"); }
        return js;
      },
      char: { x: 760, y: hasTitle ? 1130 : 1080, size: 290 },
    };
  },
  // 체크리스트 (최대 3개)
  checklist(s, i) {
    const items = (s.items || []).slice(0, 3);
    const rows = items.map((it, k) => `<div class="row" id="r${i}_${k}"><div class="box"><svg class="draw boil" viewBox="0 0 130 130"><path id="ck${i}_${k}" d="M22 70 L55 102 L112 30"/></svg></div><span style="font-size:${fit(it, 470, 84)}px">${esc(it)}</span></div>`).join("");
    return {
      html: `<div class="card" style="left:80px;top:700px;width:680px;height:${120 + items.length * 150}px"></div><div class="list" style="left:110px;top:760px;width:640px">${rows}</div>` + noteHtml(s, i, 120, 760 + items.length * 150 + 100),
      anim: (t0, d) => {
        let js = `fade(".card",${(t0 + .2).toFixed(2)},.35,40,"#c${i}");`;
        items.forEach((_, k) => {
          const tm = t0 + .5 + k * Math.max(.4, (d - 1.2) / items.length);
          js += `fade("#r${i}_${k}",${(tm - .2).toFixed(2)},.3,30);draw("ck${i}_${k}",${tm.toFixed(2)},.3);`;
          cue(tm, "tick");
        });
        if (s.note) js += `fade("#n${i}",${(t0 + d * .7).toFixed(2)},.35,20);`;
        return js;
      },
      char: { x: 770, y: 1080, size: 280 },
    };
  },
  // 전후 비교: 왼쪽(지움) vs 오른쪽(정답)
  compare(s, i) {
    const L = s.left || {}, Rr = s.right || {};
    return {
      html: `<div class="half l" id="cl${i}"><div class="ppt"><div class="ptxt" style="font-size:${fitLines(L.text, 360, 92).size}px">${fitLines(L.text, 360, 92).html}</div></div>
<div class="memo lab" style="font-size:${fit(L.label, 420, 60)}px"><span class="strike">${esc(L.label)}<i id="st${i}"></i></span></div></div>
<div class="half r" id="cr${i}"><div class="clean" id="cc${i}"><div class="t" style="font-size:${fitLines(Rr.text, 360, 86).size}px">${fitLines(Rr.text, 360, 86).html}</div><div class="u"></div></div>
<div class="memo lab" style="font-size:${fit(Rr.label, 420, 60)}px;color:var(--point)">${esc(Rr.label)}</div></div>`,
      anim: (t0, d) => {
        const a = t0 + .3, b = t0 + Math.min(1.1, d * .35), c = t0 + Math.min(1.4, d * .45);
        cue(b, "pen"); cue(c + .1, "pop");
        return `fade("#cl${i}",${a.toFixed(2)},.35,40);tl.fromTo("#st${i}",{scaleX:0},{scaleX:1,duration:.35,ease:MV,immediateRender:false},${b.toFixed(2)});fade("#cr${i}",${c.toFixed(2)},.35,40);`
          + `tl.fromTo("#cc${i}",{scale:1},{scale:1.06,duration:.3,ease:EN,immediateRender:false},${(c + .5).toFixed(2)}).to("#cc${i}",{scale:1,duration:.3,ease:MV},${(c + .85).toFixed(2)});`;
      },
      narrowTitle: true,
      char: { x: 770, y: 250, size: 250 },
    };
  },
  // 흐름: 1 → 2 → 3
  flow(s, i) {
    const steps = (s.steps || []).slice(0, 3);
    const pos = [[70, 680, -3], [370, 900, 2], [680, 1120, -2]];
    return {
      html: steps.map((t, k) => `<div class="step" id="sp${i}_${k}" style="left:${pos[k][0]}px;top:${pos[k][1]}px;transform:rotate(${pos[k][2]}deg)"><b>${k + 1}</b><span style="font-size:${fitLines(t, 230, 58).size}px">${fitLines(t, 230, 58).html}</span></div>`).join("")
        + `<svg class="draw boil" viewBox="0 0 1080 1920" style="position:absolute;inset:0;width:1080px;height:1920px"><path id="ar${i}_0" d="M250 878 C 280 930, 320 962, 362 976"/><path id="ar${i}_1" d="M560 1098 C 590 1150, 630 1182, 672 1196"/></svg>`,
      anim: (t0, d) => {
        let js = "";
        steps.forEach((_, k) => {
          const tm = t0 + .3 + k * Math.max(.45, (d - 1) / steps.length);
          js += `fade("#sp${i}_${k}",${tm.toFixed(2)},.35,30);`; cue(tm, "pop");
          if (k > 0) { js += `draw("ar${i}_${k - 1}",${(tm - .2).toFixed(2)},.3);`; cue(tm - .2, "pen"); }
        });
        if (steps.length < 3) js += `gsap.set(["#ar${i}_1"${steps.length < 2 ? `,"#ar${i}_0"` : ""}],{opacity:0});`;
        return js;
      },
      char: { x: 80, y: 1120, size: 290 },
    };
  },
  // 메모지 한 장 (테이프 + 손글씨)
  memo(s, i) {
    const tl = (s.text || "").split("\n").slice(0, 3);
    const size = Math.min(...tl.map(x => fit(x, 600, 80)));
    return {
      html: `<div class="sticky" id="mm${i}"><div class="tape" style="left:250px;top:-26px;width:220px;transform:rotate(-3deg)"></div>${tl.map(x => `<div style="font-size:${size}px">${esc(x)}</div>`).join("")}</div>` + noteHtml(s, i, 110, 1300),
      anim: (t0, d) => {
        cue(t0 + .3, "whoosh");
        let js = `tl.fromTo("#mm${i}",{y:-120,opacity:0,rotation:-8},{y:0,opacity:1,rotation:-2,duration:.5,ease:EN,immediateRender:false},${(t0 + .3).toFixed(2)});`;
        if (s.note) { const tm = t0 + Math.min(1.6, d * .55); js += `fade("#n${i}",${tm.toFixed(2)},.35,20);`; cue(tm, "pen"); }
        return js;
      },
      char: { x: 760, y: 1080, size: 290 },
    };
  },
  // 타이핑 카드 (검색창·명령어·메시지)
  typing(s, i) {
    const txt = s.text || "";
    const size = fit(txt, 780, 54);
    return {
      html: `<div class="term" id="tm${i}"><div class="dots"><i></i><i></i><i></i></div><div class="line" style="font-size:${size}px"><span style="color:var(--gray)">${esc(s.prefix ?? "> ")}</span><span id="ty${i}"></span><span class="caret" id="cr${i}"></span></div></div>`
        + (s.stamp ? `<div class="stamp" id="sm${i}" style="left:540px;top:1210px;font-size:${fit(s.stamp, 400, 120)}px">${esc(s.stamp)}</div>` : "") + noteHtml(s, i, 420, 1240, -6),
      anim: (t0, d) => {
        const td = Math.min(1.6, Math.max(.6, txt.length * .07));
        cue(t0 + .5, "type");
        let js = `fade("#tm${i}",${(t0 + .25).toFixed(2)},.35,40);type("ty${i}",${J(txt)},${(t0 + .5).toFixed(2)},${td.toFixed(2)},"cr${i}");`;
        if (s.stamp) { js += `gsap.set("#sm${i}",{opacity:0});slam("sm${i}",${(t0 + .6 + td).toFixed(2)});`; cue(t0 + .6 + td, "pop"); }
        else if (s.note) js += `fade("#n${i}",${(t0 + .7 + td).toFixed(2)},.35,20);`;
        return js;
      },
      char: { x: 80, y: 1170, size: 280 },
    };
  },
  // 말풍선 (캐릭터가 말하는 느낌)
  quote(s, i) {
    const txt = s.text || "";
    return {
      html: `<div class="bubble" id="bb${i}"><div class="who">${esc(s.who || "")}</div><div class="msg" id="bm${i}" style="font-size:${fit(txt, 740, 92)}px"></div></div>` + noteHtml(s, i, 520, 1170, -8),
      anim: (t0, d) => {
        cue(t0 + .5, "type");
        let js = `fade("#bb${i}",${(t0 + .25).toFixed(2)},.35,40);type("bm${i}",${J(txt)},${(t0 + .5).toFixed(2)},${Math.min(1.2, txt.length * .06 + .2).toFixed(2)});`;
        if (s.note) { const tm = t0 + Math.min(1.9, d * .6); js += `fade("#n${i}",${tm.toFixed(2)},.35,20);`; cue(tm, "pen"); }
        return js;
      },
      char: { x: 70, y: 1110, size: 300 },
    };
  },
  // 사진 한 장 (폴라로이드). 작업폴더/사진/ 의 파일 이름을 src 에
  photo(s, i) {
    if (s.src) { const p = path.join(work, "사진", s.src); if (fs.existsSync(p)) fs.copyFileSync(p, path.join(hf, "assets", s.src)); }
    return {
      html: `<div class="polar" id="po${i}"><div class="pimg" style="background-image:url(assets/${esc(s.src || "")})"></div><div class="pcap" style="font-size:${fit(s.caption || "", 640, 64)}px">${esc(s.caption || "")}</div></div><div class="tape" id="pt${i}" style="left:420px;top:660px;width:240px;transform:rotate(-4deg)"></div>`,
      anim: (t0) => { cue(t0 + .3, "whoosh"); return `tl.fromTo("#po${i}",{y:140,opacity:0,rotation:6},{y:0,opacity:1,rotation:-2,duration:.55,ease:EN,immediateRender:false},${(t0 + .3).toFixed(2)});fade("#pt${i}",${(t0 + .7).toFixed(2)},.25,-20);`; },
      char: { x: 790, y: 1150, size: 260 },
    };
  },
  // 마무리: 댓글 키워드
  cta(s, i) {
    const kw = s.keyword || "키워드";
    return {
      html: `<div class="bubble" id="bb${i}" style="top:700px"><div class="who">댓글 달기…</div><div class="msg" id="bm${i}" style="font-size:${fit(kw, 740, 96)}px"></div></div>`
        + `<div class="stamp" id="sm${i}" style="left:250px;top:1070px;font-size:${fit(kw, 420, 190)}px;padding:10px 46px 20px">${esc(kw)}</div>`,
      anim: (t0, d) => {
        cue(t0 + .55, "type"); cue(t0 + 1.15, "pop");
        return `fade("#bb${i}",${(t0 + .25).toFixed(2)},.35,40);type("bm${i}",${J(kw)},${(t0 + .55).toFixed(2)},.4);gsap.set("#sm${i}",{opacity:0});slam("sm${i}",${(t0 + 1.15).toFixed(2)});`;
      },
      char: { x: 770, y: 1110, size: 300 },
    };
  },
};

// ── 캐릭터 모션(코드). 포즈별 기본: idle 둥실 · think 갸웃 · happy 찌그러졌다 펴짐 · point/wave 손 흔들기 회전
function charMotion(id, pose, t0, d, mode) {
  const m = mode || { idle: "float", think: "tilt", happy: "squash", point: "wave", wave: "wave", shrug: "tilt" }[pose] || "float";
  let js = `tl.fromTo("#${id}",{y:40,opacity:0},{y:0,opacity:1,duration:.45,ease:EN,immediateRender:false},${(t0 + .15).toFixed(2)});`;
  const inner = `#${id} .ci`;
  const reps = Math.max(1, Math.floor((d - .4) / .8));
  if (m === "float") js += `tl.fromTo("${inner}",{y:0},{y:-14,duration:.8,ease:MV,yoyo:true,repeat:${reps},immediateRender:false},${(t0 + .4).toFixed(2)});`;
  if (m === "tilt") js += `tl.fromTo("${inner}",{rotation:0},{rotation:-7,duration:.8,ease:MV,yoyo:true,repeat:${reps},immediateRender:false},${(t0 + .4).toFixed(2)});`;
  if (m === "wave") js += `tl.fromTo("${inner}",{rotation:-5},{rotation:5,duration:.4,ease:MV,yoyo:true,repeat:${Math.max(1, Math.floor((d - .4) / .4))},immediateRender:false},${(t0 + .4).toFixed(2)});`;
  if (m === "squash") {
    let t = t0 + .45; let k = 0;
    while (t < t0 + d - .6 && k < 4) {
      js += `tl.fromTo("${inner}",{scaleX:1,scaleY:1},{scaleX:1.08,scaleY:.9,duration:.18,ease:MV,immediateRender:false},${t.toFixed(2)}).to("${inner}",{scaleX:.96,scaleY:1.06,y:-26,duration:.25,ease:EN},${(t + .18).toFixed(2)}).to("${inner}",{scaleX:1,scaleY:1,y:0,duration:.3,ease:MV},${(t + .43).toFixed(2)});`;
      t += 1.1; k++;
    }
  }
  return js;
}

// ── 조립
let body = "", anims = "";
scenes.forEach((s, i) => {
  const rec = R[s.type] || R.memo;
  const r = rec(s, i);
  const pose = s.char || "idle";
  const slot = s.char_pos || r.char;
  let ch = "";
  if (s.char !== "none" && slot) {
    const src = charSrc(pose);
    ch = `<div class="chr" id="ch${i}" style="left:${slot.x}px;top:${slot.y}px;width:${slot.size}px;height:${slot.size}px"><div class="ci">${src ? `<img src="${src}" alt="">` : defaultChar(pose)}</div></div>`;
  }
  const start = i === 0 ? 0 : s.t0 - .15;
  const dur = s.t1 - start + (i === scenes.length - 1 ? 0 : .15);
  body += `\n<!-- ${i + 1}. ${s.type} ${s.t0.toFixed(2)}~${s.t1.toFixed(2)} -->\n<section id="s${i}" class="clip" data-start="${start.toFixed(3)}" data-duration="${dur.toFixed(3)}" data-track-index="1"><div class="sc" id="c${i}">\n${titleHtml(s, i, r.narrowTitle)}\n${r.html}\n${ch}\n</div></section>`;
  anims += `\n// ${i + 1}. ${s.type}\n`;
  if (i > 0) { anims += `whip("c${i - 1}","c${i}",${s.t0.toFixed(3)});`; cue(s.t0 - .12, "whoosh"); }
  anims += `cam("c${i}",${s.t0.toFixed(3)},${(s.d + .3).toFixed(2)});`;
  anims += titleAnim(s, i, s.t0) + r.anim(s.t0, s.d);
  if (ch) anims += charMotion(`ch${i}`, pose, s.t0, s.d, s.motion);
});

const C = st.colors, F = st.fonts;
const caps = TM.captions.map(c => [c.start, c.end, c.text]);
const html = fs.readFileSync(path.join(SKILL_DIR, "template", "index.html"), "utf8")
  .replaceAll("{{PAPER}}", C.paper).replaceAll("{{INK}}", C.ink).replaceAll("{{MARK}}", C.highlight)
  .replaceAll("{{POINT}}", C.point).replaceAll("{{GRAY}}", C.gray).replaceAll("{{NOTEPAPER}}", C.note_paper)
  .replaceAll("{{F_TITLE}}", F.title).replaceAll("{{F_NOTE_KO}}", F.note_ko).replaceAll("{{F_NOTE_EN}}", F.note_en)
  .replaceAll("{{F_CAP}}", F.caption).replaceAll("{{F_MONO}}", F.mono)
  .replaceAll("{{CAP_SIZE}}", String(st.sizes.caption)).replaceAll("{{CAP_TOP}}", String(st.sizes.caption_top))
  .replaceAll("{{END}}", String(END)).replaceAll("{{BOIL}}", st.character.boil ? "1" : "0")
  .replace("{{SCENES}}", body).replace("{{ANIMS}}", anims).replace("{{CAPTIONS}}", J(caps));
fs.writeFileSync(path.join(hf, "index.html"), html);
cues.sort((a, b) => a.t - b.t);
fs.writeFileSync(path.join(work, "sfx_cues.json"), JSON.stringify(cues, null, 1));
console.log(`장면 ${scenes.length}개 · 길이 ${END}초 · 효과음 자리 ${cues.length}개 · 캐릭터 ${userPoseList.length ? "내 그림(" + userPoseList.join(", ") + ")" : "기본 손그림"}`);
scenes.forEach((s, i) => console.log(`  ${i + 1}. ${s.type.padEnd(9)} ${s.t0.toFixed(2)}~${s.t1.toFixed(2)}  ${(s.title || []).join(" / ")}`));
