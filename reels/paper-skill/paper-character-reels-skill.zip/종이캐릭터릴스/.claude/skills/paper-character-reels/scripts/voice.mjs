// 2단계: 나레이션 + 자막 타이밍.  node scripts/voice.mjs <작업폴더>
// - 작업폴더에 녹음.m4a / 녹음.mp3 / 녹음.wav 가 있으면 그 녹음을 쓴다 (0.3초 넘는 공백은 잘라냄)
// - 없으면 맥 say(무료 기본 음성)로 문장마다 읽고 이어 붙인다
// 결과: 작업폴더/narration.wav, 작업폴더/timing.json
import fs from "node:fs";
import path from "node:path";
import { run, duration, readLines, loadStyle, need } from "./lib.mjs";

const work = path.resolve(process.argv[2] || ".");
const st = loadStyle(work);
const tmp = path.join(work, "_tmp_voice");
fs.mkdirSync(tmp, { recursive: true });

need(path.join(work, "대본.txt"), "대본.txt 가 없어요. 한 줄에 한 문장씩 적어 주세요.");
const lines = readLines(path.join(work, "대본.txt"));
const readFile = path.join(work, "대본_읽기.txt");
const readLinesArr = fs.existsSync(readFile) ? readLines(readFile) : lines;
if (readLinesArr.length !== lines.length) {
  console.error("대본_읽기.txt 줄 수가 대본.txt 와 달라요. 줄 수를 맞춰 주세요.");
  process.exit(1);
}

const SR = 48000;
const TRIM = "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.02,areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.04,areverse";
const rec = ["녹음.m4a", "녹음.mp3", "녹음.wav", "녹음.aiff", "녹음.mp4", "녹음.mov"].map(f => path.join(work, f)).find(f => fs.existsSync(f));

let segs = []; // {text,start,end}
const outWav = path.join(work, "narration.wav");

if (!rec) {
  // ── 무료 음성으로 문장별 생성
  const pieces = [];
  readLinesArr.forEach((t, i) => {
    const raw = path.join(tmp, `l${i}.${process.platform === "win32" ? "wav" : "aiff"}`);
    if (process.platform === "darwin") {
      run("say", ["-v", st.voice.mac_voice, "-r", String(st.voice.mac_rate), "-o", raw, t]);
    } else if (process.platform === "win32") {
      const ps = `Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $v=$s.GetInstalledVoices()|?{$_.VoiceInfo.Culture.Name -eq 'ko-KR'}|select -First 1; if($v){$s.SelectVoice($v.VoiceInfo.Name)}; $s.Rate=1; $s.SetOutputToWaveFile('${raw}'); $s.Speak([IO.File]::ReadAllText('${raw}.txt')); $s.Dispose()`;
      fs.writeFileSync(raw + ".txt", t, "utf8");
      run("powershell", ["-NoProfile", "-Command", ps]);
    } else {
      console.error("이 컴퓨터엔 무료 음성이 없어요. 작업 폴더에 녹음.m4a 를 넣어 주세요."); process.exit(1);
    }
    const w = path.join(tmp, `l${i}.wav`);
    run("ffmpeg", ["-v", "error", "-y", "-i", raw, "-af", TRIM, "-ar", String(SR), "-ac", "1", w]);
    pieces.push(w);
  });
  const gap = path.join(tmp, "gap.wav");
  run("ffmpeg", ["-v", "error", "-y", "-f", "lavfi", "-i", `anullsrc=r=${SR}:cl=mono`, "-t", String(st.voice.gap_sec), gap]);
  const lead = path.join(tmp, "lead.wav");
  run("ffmpeg", ["-v", "error", "-y", "-f", "lavfi", "-i", `anullsrc=r=${SR}:cl=mono`, "-t", "0.15", lead]);
  const list = [lead];
  let t = 0.15;
  pieces.forEach((p, i) => {
    const d = duration(p);
    segs.push({ text: lines[i], start: +t.toFixed(3), end: +(t + d).toFixed(3) });
    t += d;
    list.push(p);
    if (i < pieces.length - 1) { list.push(gap); t += st.voice.gap_sec; }
  });
  const lst = path.join(tmp, "list.txt");
  fs.writeFileSync(lst, list.map(f => `file '${f.replace(/'/g, "'\\''")}'`).join("\n"));
  run("ffmpeg", ["-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-ar", String(SR), "-ac", "1", outWav]);
} else {
  // ── 녹음 파일: 긴 공백 줄이고, 공백 위치로 문장 경계 찾기
  console.log("녹음 파일 사용:", path.basename(rec));
  const src = path.join(tmp, "rec.wav");
  run("ffmpeg", ["-v", "error", "-y", "-i", rec, "-vn", "-ar", String(SR), "-ac", "1", "-af", TRIM, src]);
  const total = duration(src);
  const r = run("ffmpeg", ["-hide_banner", "-i", src, "-af", `silencedetect=noise=-38dB:d=${st.voice.silence_cut_sec}`, "-f", "null", "-"], { allowFail: true });
  const sil = [];
  let s0 = null;
  for (const ln of r.stderr.split("\n")) {
    const a = ln.match(/silence_start: ([\d.]+)/); if (a) s0 = parseFloat(a[1]);
    const b = ln.match(/silence_end: ([\d.]+)/); if (b && s0 !== null) { sil.push([s0, parseFloat(b[1])]); s0 = null; }
  }
  // 말소리 구간
  const keep = []; let cur = 0;
  for (const [a, b] of sil) { if (a > cur) keep.push([cur, a]); cur = b; }
  if (cur < total) keep.push([cur, total]);
  const KEEP_GAP = 0.12;
  // 새 타임라인 위의 공백 중간점 = 문장 경계 후보
  const parts = []; let t = 0; const cand = [];
  keep.forEach(([a, b], i) => {
    parts.push(`[0:a]atrim=${a}:${b},asetpts=PTS-STARTPTS[p${i}]`);
    t += b - a;
    if (i < keep.length - 1) { cand.push(t + KEEP_GAP / 2); t += KEEP_GAP; }
  });
  const newTotal = t;
  const gaps = keep.slice(0, -1).map((_, i) => `[g${i}]`);
  const gapSrc = keep.slice(0, -1).map((_, i) => `anullsrc=r=${SR}:cl=mono,atrim=0:${KEEP_GAP}[g${i}]`);
  const order = keep.map((_, i) => `[p${i}]` + (i < keep.length - 1 ? `[g${i}]` : "")).join("");
  const fc = [...parts, ...gapSrc, `${order}concat=n=${keep.length * 2 - 1}:v=0:a=1[out]`].join(";");
  run("ffmpeg", ["-v", "error", "-y", "-i", src, "-filter_complex", fc, "-map", "[out]", "-ar", String(SR), "-ac", "1", outWav]);
  // 글자 수 비율로 경계 목표를 잡고 가장 가까운 공백에 붙인다
  const w = lines.map(l => l.replace(/\s/g, "").length);
  const sum = w.reduce((a, b) => a + b, 0);
  const bounds = []; let acc = 0; let ci = 0;
  for (let i = 0; i < lines.length - 1; i++) {
    acc += w[i];
    const target = newTotal * acc / sum;
    let best = null;
    for (let j = ci; j < cand.length; j++) {
      if (best === null || Math.abs(cand[j] - target) < Math.abs(cand[best] - target)) best = j;
    }
    if (best !== null && Math.abs(cand[best] - target) < 1.2) { bounds.push(cand[best]); ci = best + 1; }
    else bounds.push(target);
  }
  let st0 = 0;
  lines.forEach((l, i) => {
    const en = i < bounds.length ? bounds[i] - KEEP_GAP / 2 : newTotal;
    segs.push({ text: l, start: +st0.toFixed(3), end: +en.toFixed(3) });
    st0 = i < bounds.length ? bounds[i] + KEEP_GAP / 2 : newTotal;
  });
}

// ── 자막 조각: 한 줄을 12글자 안팎으로 나누고 글자 수 비율로 시간 배분
function chunk(text) {
  const words = text.split(/\s+/); const out = []; let cur = "";
  for (const wd of words) {
    const nxt = cur ? cur + " " + wd : wd;
    if (cur && nxt.replace(/\s/g, "").length > 12) { out.push(cur); cur = wd; } else cur = nxt;
  }
  if (cur) out.push(cur);
  // 끝 조각이 너무 짧으면(4글자 이하) 앞 조각에 붙인다
  if (out.length > 1 && out[out.length - 1].replace(/[\s.,!?…]/g, "").length <= 5) { const last = out.pop(); out[out.length - 1] += " " + last; }
  return out;
}
const caps = [];
for (const s of segs) {
  const parts = chunk(s.text);
  const n = parts.map(p => p.replace(/\s/g, "").length);
  const tot = n.reduce((a, b) => a + b, 0);
  let t = s.start;
  parts.forEach((p, i) => {
    const d = (s.end - s.start) * n[i] / tot;
    caps.push({ text: p, start: +t.toFixed(3), end: +(i === parts.length - 1 ? s.end : t + d).toFixed(3) });
    t += d;
  });
}
const total = duration(outWav);
fs.writeFileSync(path.join(work, "timing.json"), JSON.stringify({ total: +total.toFixed(3), lines: segs, captions: caps }, null, 2));
fs.rmSync(tmp, { recursive: true, force: true });
console.log(`나레이션 ${total.toFixed(1)}초 · 문장 ${segs.length}개 · 자막 ${caps.length}조각`);
segs.forEach((s, i) => console.log(`  ${i + 1}. ${s.start.toFixed(2)}~${s.end.toFixed(2)}  ${s.text}`));
