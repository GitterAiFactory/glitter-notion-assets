// 공용 도우미
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

export const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

export function loadStyle(workDir) {
  const base = JSON.parse(fs.readFileSync(path.join(SKILL_DIR, "style.json"), "utf8"));
  const local = workDir && path.join(workDir, "style.json");
  if (local && fs.existsSync(local)) {
    const o = JSON.parse(fs.readFileSync(local, "utf8"));
    for (const k of Object.keys(o)) {
      if (typeof o[k] === "object" && !Array.isArray(o[k]) && base[k]) Object.assign(base[k], o[k]);
      else base[k] = o[k];
    }
  }
  return base;
}

export function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { encoding: "utf8", maxBuffer: 1 << 28, ...opts });
  if (r.error) throw r.error;
  if (r.status !== 0 && !opts.allowFail) {
    throw new Error(`${cmd} 실패 (코드 ${r.status})\n${(r.stderr || "").slice(-2000)}`);
  }
  return r;
}

export function has(cmd) {
  const r = spawnSync(process.platform === "win32" ? "where" : "which", [cmd], { encoding: "utf8" });
  return r.status === 0;
}

export function duration(file) {
  const r = run("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]);
  return parseFloat(r.stdout.trim());
}

export function readLines(file) {
  return fs.readFileSync(file, "utf8").split(/\r?\n/).map(s => s.trim()).filter(Boolean);
}

export function need(file, msg) {
  if (!fs.existsSync(file)) { console.error(msg || `파일이 없어요: ${file}`); process.exit(1); }
}
