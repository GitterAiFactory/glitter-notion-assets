// 4단계: 렌더 + 효과음 + 검수 프레임.  node scripts/render.mjs <작업폴더> [이름]
// 결과: 작업폴더/결과/<이름>_v1.mp4 (다시 렌더하면 _v2, _v3 … 덮어쓰지 않음)
//       작업폴더/검수/sheet.jpg (장면 가운데 프레임 모음 — 글자 겹침 확인용)
import fs from "node:fs";
import path from "node:path";
import { SKILL_DIR, loadStyle, run, duration } from "./lib.mjs";

const work = path.resolve(process.argv[2] || ".");
const name = process.argv[3] || path.basename(work);
const st = loadStyle(work);
const hf = path.join(work, "hf");
const tmp = path.join(work, "_tmp_render");
fs.mkdirSync(tmp, { recursive: true });
const raw = path.join(tmp, "raw.mp4");

console.log("렌더 중… (20초 영상 기준 보통 1~4분)");
const npx = process.platform === "win32" ? "npx.cmd" : "npx";
run(npx, ["--yes", `hyperframes@${st.render.hyperframes}`, "render", hf, "-o", raw, "-f", String(st.render.fps), "-q", "delivery", "--quiet"],
  { stdio: ["ignore", "inherit", "inherit"], shell: process.platform === "win32" });

// ── 효과음: 내 효과음 폴더(작업폴더/효과음/pop.wav 등)가 있으면 그걸, 없으면 코드로 만든 소리
function sfxFile(kind) {
  for (const ext of ["wav", "mp3", "m4a"]) {
    const f = path.join(work, "효과음", `${kind}.${ext}`);
    if (fs.existsSync(f)) return f;
  }
  const f = path.join(tmp, `${kind}.wav`);
  if (fs.existsSync(f)) return f;
  const gen = {
    pop: ["-f", "lavfi", "-i", "aevalsrc='0.9*sin(2*PI*(380+700*exp(-t*35))*t)*exp(-t*28)':s=48000:d=0.18"],
    tick: ["-f", "lavfi", "-i", "aevalsrc='0.7*sin(2*PI*1500*t)*exp(-t*70)+0.3*sin(2*PI*2400*t)*exp(-t*90)':s=48000:d=0.08"],
    whoosh: ["-f", "lavfi", "-i", "anoisesrc=color=pink:r=48000:d=0.38:a=0.6", "-af", "highpass=f=500,lowpass=f=3500,afade=t=in:d=0.16:curve=qsin,afade=t=out:st=0.18:d=0.2:curve=qsin"],
    pen: ["-f", "lavfi", "-i", "anoisesrc=color=white:r=48000:d=0.32:a=0.35", "-af", "bandpass=f=3200:width_type=h:w=2200,tremolo=f=16:d=0.8,afade=t=in:d=0.04,afade=t=out:st=0.2:d=0.12"],
    type: ["-f", "lavfi", "-i", "aevalsrc='0.5*sin(2*PI*1900*mod(t,0.09))*exp(-mod(t,0.09)*120)':s=48000:d=0.55"],
  }[kind];
  run("ffmpeg", ["-v", "error", "-y", ...gen, "-ac", "1", f]);
  return f;
}

const results = path.join(work, "결과");
fs.mkdirSync(results, { recursive: true });
let v = 1;
while (fs.existsSync(path.join(results, `${name}_v${v}.mp4`))) v++;
const out = path.join(results, `${name}_v${v}.mp4`);

const cuesFile = path.join(work, "sfx_cues.json");
if (st.sfx.on && fs.existsSync(cuesFile)) {
  const cues = JSON.parse(fs.readFileSync(cuesFile, "utf8")).filter(c => c.t >= 0);
  // 너무 붙은 소리는 하나만
  const keep = []; for (const c of cues) { if (!keep.length || c.t - keep[keep.length - 1].t > 0.18) keep.push(c); }
  const vol = st.sfx.volume;
  const args = ["-v", "error", "-y", "-i", raw];
  const fc = [];
  keep.forEach((c, k) => {
    args.push("-i", sfxFile(c.kind));
    const vv = c.kind === "whoosh" ? vol * 0.8 : c.kind === "pen" ? vol * 0.9 : vol;
    fc.push(`[${k + 1}:a]aresample=48000,adelay=${Math.round(c.t * 1000)}:all=1,volume=${vv.toFixed(2)}[s${k}]`);
  });
  fc.push(`[0:a]aresample=48000[v0];[v0]${keep.map((_, k) => `[s${k}]`).join("")}amix=inputs=${keep.length + 1}:normalize=0:duration=first,alimiter=limit=0.95[a]`);
  run("ffmpeg", [...args, "-filter_complex", fc.join(";"), "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", out]);
} else {
  fs.copyFileSync(raw, out);
}

// ── 검수 프레임: 장면 가운데 + 전환 직후
const TM = JSON.parse(fs.readFileSync(path.join(work, "timing.json"), "utf8"));
const chk = path.join(work, "검수");
fs.mkdirSync(chk, { recursive: true });
const times = TM.lines.map(l => (l.start + l.end) / 2);
const frames = [];
times.forEach((t, k) => {
  const f = path.join(chk, `f${String(k + 1).padStart(2, "0")}_${t.toFixed(1)}s.jpg`);
  run("ffmpeg", ["-v", "error", "-y", "-ss", t.toFixed(2), "-i", out, "-frames:v", "1", "-vf", "scale=360:-1", f]);
  frames.push(f);
});
const cols = Math.min(5, frames.length);
const rows = Math.ceil(frames.length / cols);
const inputs = []; const fc2 = [];
for (let k = 0; k < rows * cols; k++) {
  inputs.push("-i", frames[k] || frames[frames.length - 1]);
  fc2.push(`[${k}]${frames[k] ? "null" : "drawbox=c=white:t=fill"}[i${k}]`);
}
const rowStr = []; for (let r = 0; r < rows; r++) { fc2.push(`${Array.from({ length: cols }, (_, c) => `[i${r * cols + c}]`).join("")}hstack=${cols}[r${r}]`); rowStr.push(`[r${r}]`); }
fc2.push(rows > 1 ? `${rowStr.join("")}vstack=${rows}` : `[r0]null`);
run("ffmpeg", ["-v", "error", "-y", ...inputs, "-filter_complex", fc2.join(";"), path.join(chk, "sheet.jpg")]);

fs.rmSync(tmp, { recursive: true, force: true });
console.log(`완성: ${out} (${duration(out).toFixed(1)}초)`);
console.log(`검수 시트: ${path.join(chk, "sheet.jpg")}`);
