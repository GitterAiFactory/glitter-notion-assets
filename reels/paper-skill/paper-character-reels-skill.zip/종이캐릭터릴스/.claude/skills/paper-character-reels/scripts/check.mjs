// 1단계: 준비물 확인. node scripts/check.mjs
import { has, run, loadStyle } from "./lib.mjs";

const st = loadStyle();
const out = [];
let ok = true;

const major = parseInt(process.versions.node.split(".")[0], 10);
if (major >= 18) out.push(`✔ Node ${process.versions.node}`);
else { ok = false; out.push(`✘ Node가 너무 옛날 버전이에요(${process.versions.node}). https://nodejs.org 에서 LTS를 받아 설치해 주세요.`); }

for (const c of ["ffmpeg", "ffprobe"]) {
  if (has(c)) out.push(`✔ ${c}`);
  else {
    ok = false;
    out.push(process.platform === "darwin"
      ? `✘ ${c} 없음 → 터미널에서: brew install ffmpeg   (brew가 없으면 https://brew.sh 첫 줄부터)`
      : process.platform === "win32"
        ? `✘ ${c} 없음 → PowerShell에서: winget install Gyan.FFmpeg  (설치 후 창을 새로 열기)`
        : `✘ ${c} 없음 → sudo apt install ffmpeg`);
  }
}

if (process.platform === "darwin") {
  out.push(has("say") ? "✔ 맥 기본 음성(say) — 녹음 파일이 없으면 이걸로 읽어요" : "△ say 없음 — 녹음 파일을 넣어 주세요");
} else if (process.platform === "win32") {
  out.push("△ 윈도우: 녹음 파일을 넣는 걸 추천해요. 없으면 윈도우 기본 음성으로 시도해요(한국어 음성이 깔려 있어야 해요).");
} else {
  out.push("△ 녹음 파일(녹음.m4a 등)을 넣어 주세요.");
}

const ver = st.render.hyperframes;
try {
  const r = run(process.platform === "win32" ? "npx.cmd" : "npx", ["--yes", `hyperframes@${ver}`, "--version"], { allowFail: true, shell: process.platform === "win32" });
  if (r.status === 0) out.push(`✔ HyperFrames ${r.stdout.trim()} (npx로 자동 실행)`);
  else { ok = false; out.push(`✘ HyperFrames 실행 실패. 인터넷 연결을 확인하고 다시 해 주세요.\n${(r.stderr || "").slice(-400)}`); }
} catch (e) { ok = false; out.push("✘ npx를 찾을 수 없어요. Node를 다시 설치해 주세요."); }

console.log(out.join("\n"));
console.log(ok ? "\n준비 끝. 바로 만들 수 있어요." : "\n위 ✘ 항목부터 설치해 주세요.");
process.exit(ok ? 0 : 1);
